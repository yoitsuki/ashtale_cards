/* global React, ReactDOM, CARD_DATA */
const { useState, useMemo, useEffect } = React;

// ----- constants -----
const CATEGORIES = ["武器", "腕", "防具", "装飾", "頭"];
const RARES = ["幻", "鋼", "天", "赤", "金"];
const RANKS = ["12", "11", "10", "9", "8", "7", "6", "3", "1"];
const STATUSES = [
  "攻撃%", "会心率", "会心ダメージ", "防御無視", "ダメージ倍率",
  "対ボス与ダメ増", "対高HP与ダメ増", "対低HP与ダメ増", "状態異常与ダメ増",
  "命中率", "状態異常命中率", "防御%", "HP%", "ガード率", "回避率",
  "会心率耐性", "会心ダメ耐性", "対高低HPダメ耐性", "対ボス被ダメ減",
  "状態異常耐性", "状態異常ダメ耐性", "与治療効果", "被治療効果", "HP吸収率",
];

const STATUS_ALIAS = {
  "攻撃%": "攻撃", "防御%": "防御", "HP%": "HP",
};
const aliasOf = (s) => STATUS_ALIAS[s] || s;

// ----- helpers -----
const numOf = (val) => {
  const m = String(val).match(/[-+]?\d+(\.\d+)?/);
  return m ? parseFloat(m[0]) : 0;
};

const cardMatchesStatus = (card, statusFilters, mode) => {
  if (!statusFilters.length) return true;
  const cardStatusNames = card.stats.map(([n]) => aliasOf(n));
  const targets = statusFilters.map(aliasOf);
  return mode === "AND"
    ? targets.every(t => cardStatusNames.includes(t))
    : targets.some(t => cardStatusNames.includes(t));
};

// ----- header -----
function Header() {
  return (
    <div className="app-head">
      <div className="app-mark">
        <div className="mark-glyph">A</div>
        <div className="mark-text">AshTale カード図鑑</div>
      </div>
      <button className="head-action" aria-label="メニュー">≡</button>
    </div>
  );
}

// ----- search box -----
function Search({ value, onChange }) {
  return (
    <div className="search">
      <span className="icon">⌕</span>
      <input
        type="text"
        placeholder="カード名で検索"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

// ----- AND/OR + reset toolbar -----
function Toolbar({ mode, setMode, onReset }) {
  return (
    <div className="toolbar">
      <div className="seg" role="group" aria-label="検索モード">
        <button className={mode === "AND" ? "on" : ""} onClick={() => setMode("AND")}>AND</button>
        <button className={mode === "OR" ? "on" : ""} onClick={() => setMode("OR")}>OR</button>
      </div>
      <div className="grow"></div>
      <button className="btn-link" onClick={onReset}>条件をリセット</button>
    </div>
  );
}

// ----- filter group -----
function TagGroup({ label, options, active, onToggle, mono, rare, collapsible }) {
  const [open, setOpen] = useState(!collapsible);
  return (
    <div className="taggroup">
      <div className="ghead">
        <span className="glabel">{label}</span>
        <span className="gcount">{active.length} / {options.length}</span>
      </div>
      <div className={`tags ${collapsible ? "tags-clip" : ""} ${open ? "open" : ""}`}>
        {options.map((o) => {
          const cls = ["tag"];
          if (active.includes(o)) cls.push("on");
          if (mono) cls.push("mono");
          if (rare) cls.push("rare", `rare-${o}`);
          return (
            <button key={o} className={cls.join(" ")} onClick={() => onToggle(o)}>{o}</button>
          );
        })}
      </div>
      {collapsible && (
        <button className="btn-more" onClick={() => setOpen(!open)}>
          {open ? "− 折りたたむ" : "+ もっと見る"}
        </button>
      )}
    </div>
  );
}

// ----- card row -----
function CardRow({ card, statusFilters, maxByStat, onOpen }) {
  const targets = statusFilters.map(aliasOf);
  // primary stats to show as bars (top 3 by absolute value, ensure highlighted ones come first)
  const sorted = [...card.stats]
    .map(([n, v]) => ({ name: n, val: v, alias: aliasOf(n), n: numOf(v) }))
    .sort((a, b) => {
      const aH = targets.includes(a.alias) ? 1 : 0;
      const bH = targets.includes(b.alias) ? 1 : 0;
      if (aH !== bH) return bH - aH;
      return Math.abs(b.n) - Math.abs(a.n);
    });
  const shown = sorted.slice(0, 3);

  return (
    <div className={`cardrow r-${card.rare}`} onClick={() => onOpen(card)}>
      <div className="thumb">
        <div className={`badge r-${card.rare}`}>{card.rare}</div>
      </div>
      <div className="body">
        <div className="row1">
          <div className="nm">{card.name}</div>
          <div className="rk">R{card.rank}</div>
        </div>
        <div className="row2">
          <span className="rare-mark"></span>
          <span>{card.rare}</span>
          <span className="sep">·</span>
          <span>{card.category}</span>
        </div>
        <div className="stats">
          {shown.map((s, i) => {
            const hi = targets.includes(s.alias);
            const max = maxByStat[s.alias] || 50;
            const pct = Math.min(100, Math.max(6, (Math.abs(s.n) / max) * 100));
            return (
              <div key={i} className={`stat-bar ${hi ? "hi" : ""}`}>
                <div className="row">
                  <div className="lbl">{s.name}</div>
                  <div className="val">{s.val}</div>
                </div>
                <div className="track"><div className="fill" style={{ width: pct + "%" }}></div></div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ----- modal -----
function Modal({ card, onClose }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  if (!card) return null;
  const max = Math.max(...card.stats.map(([, v]) => Math.abs(numOf(v))), 30);

  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>×</button>
        <div className="modal-art">
          <div className="ph-label">{card.name}</div>
        </div>
        <div className="modal-info">
          <div className="modal-cat">{card.category}</div>
          <h2 className="modal-name">{card.name}</h2>
          <div className="modal-tags">
            <span className="modal-tag rank">RANK {card.rank}</span>
            <span className={`modal-tag rare`} style={{ ["--rare-dot"]: rareColor(card.rare) }}>
              <span className="swatch"></span>{card.rare}
            </span>
            <span className="modal-tag">{card.category}</span>
          </div>
          <h3 className="modal-section-h">ステータス（フルオプ）</h3>
          <div className="modal-stats">
            {card.stats.map(([name, val], i) => {
              const pct = Math.min(100, (Math.abs(numOf(val)) / max) * 100);
              return (
                <div key={i} className="stat-bar">
                  <div className="row">
                    <div className="lbl">{name}</div>
                    <div className="val">{val}</div>
                  </div>
                  <div className="track"><div className="fill" style={{ width: pct + "%" }}></div></div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

const rareColor = (r) => ({ "幻": "#6a5fa8", "鋼": "#7d8597", "天": "#c19a4e", "赤": "#b04e44", "金": "#a07a23" }[r]);

// ----- main app -----
function App() {
  const [name, setName] = useState("");
  const [cats, setCats] = useState([]);
  const [rares, setRares] = useState([]);
  const [ranks, setRanks] = useState([]);
  const [stats, setStats] = useState([]);
  const [mode, setMode] = useState("AND");
  const [sort, setSort] = useState("rank-desc");
  const [open, setOpen] = useState(null);

  const toggle = (list, setList) => (v) => {
    setList(list.includes(v) ? list.filter(x => x !== v) : [...list, v]);
  };
  const reset = () => {
    setName(""); setCats([]); setRares([]); setRanks([]); setStats([]); setMode("AND");
  };

  const filtered = useMemo(() => {
    return CARD_DATA.filter(c => {
      if (name && !c.name.toLowerCase().includes(name.toLowerCase())) return false;
      if (cats.length && !cats.includes(c.category)) return false;
      if (rares.length && !rares.includes(c.rare)) return false;
      if (ranks.length && !ranks.includes(String(c.rank))) return false;
      if (!cardMatchesStatus(c, stats, mode)) return false;
      return true;
    });
  }, [name, cats, rares, ranks, stats, mode]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    if (sort === "rank-desc") arr.sort((a, b) => b.rank - a.rank);
    if (sort === "rank-asc") arr.sort((a, b) => a.rank - b.rank);
    if (sort === "rare") {
      const order = { "幻": 0, "鋼": 1, "天": 2, "赤": 3, "金": 4 };
      arr.sort((a, b) => (order[a.rare] - order[b.rare]) || (b.rank - a.rank));
    }
    if (sort === "name") arr.sort((a, b) => a.name.localeCompare(b.name, "ja"));
    return arr;
  }, [filtered, sort]);

  // build per-stat max for bar normalisation
  const maxByStat = useMemo(() => {
    const m = {};
    CARD_DATA.forEach(c => c.stats.forEach(([n, v]) => {
      const a = aliasOf(n); const num = Math.abs(numOf(v));
      if (!m[a] || num > m[a]) m[a] = num;
    }));
    return m;
  }, []);

  const cycleSort = () => {
    const order = ["rank-desc", "rank-asc", "rare", "name"];
    setSort(order[(order.indexOf(sort) + 1) % order.length]);
  };
  const sortLabel = {
    "rank-desc": "ランク高い順",
    "rank-asc": "ランク低い順",
    "rare": "レア度順",
    "name": "名前順",
  }[sort];

  const activeChips = [
    ...cats.map(v => ({ k: "カテゴリ", v })),
    ...rares.map(v => ({ k: "レア度", v })),
    ...ranks.map(v => ({ k: "ランク", v: "R" + v })),
    ...stats.map(v => ({ k: "ステータス", v })),
  ];

  return (
    <div className="shell">
      <Header />

      <h1 className="title">カードを<em>絞り込む</em>。</h1>
      <p className="subtitle">
        全 {CARD_DATA.length} 種から条件で検索
        <span className="upd">UPD 2026.05.08</span>
      </p>

      <Search value={name} onChange={setName} />
      <Toolbar mode={mode} setMode={setMode} onReset={reset} />

      <TagGroup label="カテゴリ" options={CATEGORIES} active={cats} onToggle={toggle(cats, setCats)} />
      <TagGroup label="レア度" options={RARES} active={rares} onToggle={toggle(rares, setRares)} rare />
      <TagGroup label="ランク" options={RANKS} active={ranks} onToggle={toggle(ranks, setRanks)} mono />
      <TagGroup label="ステータス" options={STATUSES} active={stats} onToggle={toggle(stats, setStats)} collapsible />

      <div className="results-h">
        <div className="left"><span className="num">{sorted.length}</span> <span>件 ヒット</span></div>
        <button className="sort-mini" onClick={cycleSort}>↕ {sortLabel}</button>
      </div>

      {activeChips.length > 0 && (
        <div className="active-tags">
          {activeChips.map((c, i) => (
            <span key={i} className="active-tag">{c.k}: {c.v}</span>
          ))}
        </div>
      )}

      {sorted.length === 0 ? (
        <div className="empty">
          <div className="face">NO RESULT</div>
          条件に合うカードがありません
        </div>
      ) : (
        <div className="cards">
          {sorted.map(c => (
            <CardRow
              key={c.id}
              card={c}
              statusFilters={stats}
              maxByStat={maxByStat}
              onOpen={setOpen}
            />
          ))}
        </div>
      )}

      <div className="foot">
        <span>AshTale Card Index</span>
        <span>v 2.0 — Redesign Draft</span>
      </div>

      {open && <Modal card={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
