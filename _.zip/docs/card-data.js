// Sample card data based on the AshTale card index
// Real card names, fabricated stat values for visual mockup
window.CARD_DATA = [
  // 幻 (Illusion - rarest, holographic)
  { id: 1, name: "幻ユゥリ", rare: "幻", rank: 1, category: "防具", stats: [["HP", "+22%"], ["防御", "+18%"], ["対ボス被ダメ減", "+12%"], ["状態異常耐性", "+15%"]] },
  { id: 2, name: "幻ユラ", rare: "幻", rank: 1, category: "防具", stats: [["HP", "+24%"], ["ガード率", "+10%"], ["対高低HPダメ耐性", "+14%"]] },
  { id: 3, name: "幻リトス", rare: "幻", rank: 1, category: "装飾", stats: [["攻撃", "+20%"], ["会心率", "+12%"], ["会心ダメージ", "+30%"]] },

  // 鋼 (Steel - silver)
  { id: 4, name: "鋼ユゥリ", rare: "鋼", rank: 1, category: "防具", stats: [["HP", "+18%"], ["防御", "+15%"], ["状態異常耐性", "+12%"]] },
  { id: 5, name: "鋼ユラ", rare: "鋼", rank: 1, category: "防具", stats: [["HP", "+19%"], ["ガード率", "+8%"]] },

  // 天 Rank 12
  { id: 6, name: "天ナキリ", rare: "天", rank: 12, category: "武器", stats: [["攻撃", "+24%"], ["会心ダメージ", "+34%"], ["対ボス与ダメ増", "+18%"]] },
  { id: 7, name: "天エリー", rare: "天", rank: 12, category: "武器", stats: [["攻撃", "+22%"], ["会心率", "+14%"], ["ダメージ倍率", "+20%"]] },
  { id: 8, name: "天オサキE", rare: "天", rank: 12, category: "腕", stats: [["攻撃", "+20%"], ["命中率", "+15%"], ["防御無視", "+12%"]] },
  { id: 9, name: "天リュミナ", rare: "天", rank: 12, category: "防具", stats: [["HP", "+20%"], ["防御", "+16%"], ["状態異常耐性", "+18%"]] },
  { id: 10, name: "天リーチェP", rare: "天", rank: 12, category: "装飾", stats: [["攻撃", "+18%"], ["会心ダメージ", "+28%"]] },
  { id: 11, name: "天ローラ", rare: "天", rank: 12, category: "頭", stats: [["HP", "+18%"], ["回避率", "+10%"], ["命中率", "+12%"]] },
  { id: 12, name: "天ノルン", rare: "天", rank: 12, category: "頭", stats: [["HP", "+20%"], ["状態異常命中率", "+14%"]] },

  // 赤 Rank 12
  { id: 13, name: "赤ラズリ", rare: "赤", rank: 12, category: "武器", stats: [["攻撃", "+20%"], ["会心率", "+12%"]] },
  { id: 14, name: "赤バティナ", rare: "赤", rank: 12, category: "腕", stats: [["攻撃", "+18%"], ["命中率", "+12%"]] },
  { id: 15, name: "赤夢幻の化け狸", rare: "赤", rank: 12, category: "防具", stats: [["HP", "+18%"], ["対高低HPダメ耐性", "+12%"]] },
  { id: 16, name: "赤ヴォルカ", rare: "赤", rank: 12, category: "防具", stats: [["HP", "+19%"], ["防御", "+14%"]] },

  // 天 Rank 11
  { id: 17, name: "天フレイ", rare: "天", rank: 11, category: "武器", stats: [["攻撃", "+22%"], ["会心ダメージ", "+30%"]] },
  { id: 18, name: "天プランタン", rare: "天", rank: 11, category: "防具", stats: [["HP", "+19%"], ["防御", "+15%"]] },
  { id: 19, name: "天イヴェール", rare: "天", rank: 11, category: "防具", stats: [["HP", "+20%"], ["対ボス被ダメ減", "+10%"]] },
  { id: 20, name: "天スターグ", rare: "天", rank: 11, category: "頭", stats: [["HP", "+17%"], ["命中率", "+12%"]] },

  // 赤 Rank 11
  { id: 21, name: "赤ミント", rare: "赤", rank: 11, category: "武器", stats: [["攻撃", "+18%"], ["会心率", "+10%"]] },
  { id: 22, name: "赤プランタン", rare: "赤", rank: 11, category: "防具", stats: [["HP", "+17%"], ["防御", "+13%"]] },
  { id: 23, name: "赤アイスキノコ", rare: "赤", rank: 11, category: "防具", stats: [["HP", "+18%"], ["状態異常耐性", "+14%"]] },

  // 天 Rank 10
  { id: 24, name: "天マリポッサ", rare: "天", rank: 10, category: "武器", stats: [["攻撃", "+18%"], ["会心ダメージ", "+24%"]] },
  { id: 25, name: "天ヤマブシ", rare: "天", rank: 10, category: "腕", stats: [["攻撃", "+16%"], ["命中率", "+11%"]] },
  { id: 26, name: "天ロチュス", rare: "天", rank: 10, category: "装飾", stats: [["攻撃", "+15%"], ["会心率", "+9%"]] },
  { id: 27, name: "天セヘル", rare: "天", rank: 10, category: "頭", stats: [["HP", "+16%"], ["回避率", "+8%"]] },

  // 赤 Rank 10
  { id: 28, name: "赤サンドラ", rare: "赤", rank: 10, category: "武器", stats: [["攻撃", "+16%"], ["会心率", "+9%"]] },
  { id: 29, name: "赤レイドナンス", rare: "赤", rank: 10, category: "腕", stats: [["攻撃", "+15%"], ["防御無視", "+9%"]] },
  { id: 30, name: "赤ビルネ", rare: "赤", rank: 10, category: "防具", stats: [["HP", "+15%"], ["防御", "+12%"]] },

  // 天 Rank 9
  { id: 31, name: "天ハイリーン", rare: "天", rank: 9, category: "武器", stats: [["攻撃", "+15%"], ["会心ダメージ", "+22%"]] },
  { id: 32, name: "天コーラル", rare: "天", rank: 9, category: "腕", stats: [["攻撃", "+14%"], ["命中率", "+10%"]] },
  { id: 33, name: "天セドロ", rare: "天", rank: 9, category: "装飾", stats: [["攻撃", "+13%"], ["会心率", "+8%"]] },
  { id: 34, name: "天ナルシス", rare: "天", rank: 9, category: "頭", stats: [["HP", "+14%"], ["命中率", "+10%"]] },

  // 赤 Rank 9
  { id: 35, name: "赤イザベラ", rare: "赤", rank: 9, category: "武器", stats: [["攻撃", "+13%"], ["会心率", "+7%"]] },
  { id: 36, name: "赤フラガリア", rare: "赤", rank: 9, category: "武器", stats: [["攻撃", "+14%"], ["ダメージ倍率", "+11%"]] },

  // 天 Rank 8
  { id: 37, name: "天ルナ", rare: "天", rank: 8, category: "武器", stats: [["攻撃", "+13%"], ["会心ダメージ", "+18%"]] },
  { id: 38, name: "天ミーティア", rare: "天", rank: 8, category: "腕", stats: [["攻撃", "+12%"], ["命中率", "+9%"]] },
  { id: 39, name: "天ソフィア", rare: "天", rank: 8, category: "装飾", stats: [["攻撃", "+11%"], ["会心率", "+7%"]] },

  // 赤 Rank 8
  { id: 40, name: "赤エヴェレスト", rare: "赤", rank: 8, category: "武器", stats: [["攻撃", "+12%"], ["会心率", "+6%"]] },
  { id: 41, name: "赤クーロン", rare: "赤", rank: 8, category: "防具", stats: [["HP", "+12%"], ["防御", "+10%"]] },

  // Rank 7
  { id: 42, name: "天アカネR", rare: "天", rank: 7, category: "武器", stats: [["攻撃", "+10%"], ["会心ダメージ", "+15%"]] },
  { id: 43, name: "天ナナミ", rare: "天", rank: 7, category: "腕", stats: [["攻撃", "+10%"], ["命中率", "+8%"]] },
  { id: 44, name: "赤凛", rare: "赤", rank: 7, category: "武器", stats: [["攻撃", "+9%"], ["会心率", "+5%"]] },

  // Rank 6
  { id: 45, name: "赤ユイ", rare: "赤", rank: 6, category: "武器", stats: [["攻撃", "+8%"], ["会心率", "+4%"]] },
  { id: 46, name: "赤ハク", rare: "赤", rank: 6, category: "武器", stats: [["攻撃", "+8%"], ["ダメージ倍率", "+6%"]] },
  { id: 47, name: "赤フォマルハウト", rare: "赤", rank: 6, category: "腕", stats: [["攻撃", "+7%"], ["命中率", "+6%"]] },
  { id: 48, name: "赤ルーチェ", rare: "赤", rank: 6, category: "防具", stats: [["HP", "+8%"], ["防御", "+7%"]] },
  { id: 49, name: "赤マーメイド", rare: "赤", rank: 6, category: "防具", stats: [["HP", "+9%"], ["状態異常耐性", "+8%"]] },
  { id: 50, name: "赤フィーネ", rare: "赤", rank: 6, category: "頭", stats: [["HP", "+8%"], ["回避率", "+5%"]] },

  // 金 Rank 3
  { id: 51, name: "金アースドラゴン", rare: "金", rank: 3, category: "頭", stats: [["HP", "+5%"], ["防御", "+4%"]] },
];

window.CATEGORIES = ["武器", "腕", "防具", "装飾", "頭"];
window.RARES = ["幻", "鋼", "天", "赤", "金"];
window.RANKS = [12, 11, 10, 9, 8, 7, 6, 3, 1];
